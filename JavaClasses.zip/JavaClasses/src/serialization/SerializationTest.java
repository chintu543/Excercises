package serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationTest {

	public static void main(String[] args) throws IOException, ClassNotFoundException {

		Department dep = new Department(21,"Mechanical","Ramesh");
		
		EmpSerilizationUtil.serilizeEmployee(dep, "C:\\Users\\Sandeep Manchala\\Desktop\\Dep.txt");

		Department olddep = EmpSerilizationUtil.deSerilizeEmployee("C:\\Users\\Sandeep Manchala\\Desktop\\Dep.txt");
		olddep.display();

	}

}

class EmpSerilizationUtil {

	public static void serilizeEmployee(Department dep, String file) throws IOException {
		FileOutputStream fos = new FileOutputStream(file);

		ObjectOutputStream oos = new ObjectOutputStream(fos);

		oos.writeObject(dep);

		oos.flush();
		fos.flush();
		fos.close();
		oos.close();
	}

	static Department deSerilizeEmployee(String file) throws IOException, ClassNotFoundException {
		FileInputStream fis = new FileInputStream(file);

		ObjectInputStream ois = new ObjectInputStream(fis);

		Department d = (Department) ois.readObject();

		fis.close();
		ois.close();

		return d;
	}
}
