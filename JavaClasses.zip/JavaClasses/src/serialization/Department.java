package serialization;

import java.io.Serializable;

public class Department implements Serializable {
	
	int deptNo;
	String deptName;
	String deptHead;

	
	public Department() {
		super();
	}
	
	public Department(int deptNo, String deptName, String deptHead) {
		super();
		this.deptNo = deptNo;
		this.deptName = deptName;
		this.deptHead = deptHead;
	}

	void display() {
		System.out.println("Department Number is " +deptNo);
		System.out.println("Department Name is " +deptName);
		System.out.println("Departmant Head is "+deptHead);
	}
	
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public int getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}
	public String getDeptHead() {
		return deptHead;
	}
	public void setDeptHead(String deptHead) {
		this.deptHead = deptHead;
	}

}
