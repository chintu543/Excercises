package employeeArrayInterface;

import java.io.File;
import java.util.Date;
import java.util.Scanner;

import classes.EmployeeUtil;

public class EmployeeArrayUtil {

	private static Scanner sc = new Scanner(System.in);

	static void populateCSVtoArray(EmployeeAppImpl eImpl) throws Exception {
		File file = new File("C:\\Users\\Sandeep Manchala\\Desktop\\Employee.csv");
		Employee [] temp =eImpl.readEmployeesFromCSV(file);
		 for(int i=0; i<temp.length; i++) {
				if(temp[i]!= null)
					eImpl.createEmployee(temp[i]);
			  }
	}


	static Employee getNewEmpDetails() {

		System.out.println("Enter Employee Id");
		int eid = sc.nextInt();
		System.out.println("Enter Employee Number");
		int num = sc.nextInt();
		System.out.println("Enter Employee Name");
		String name = sc.next();
		System.out.println("Enter Employee Salary");
		float salary = sc.nextFloat();
		System.out.println("Enter Employee year of joining");
		int doj = sc.nextInt();
		System.out.println("Enter Employee age");
		int age = sc.nextInt();

		sc.close();
		return constructEmployee(eid, num, name, salary, EmployeeUtil.getDate(doj), age);

	}

	static Employee readEmployee() {

		System.out.println("Enter Employee Id");
		int eid = sc.nextInt();
		System.out.println("Enter Employee Number");
		int num = sc.nextInt();
		System.out.println("Enter Employee Name");
		String name = sc.next();
		System.out.println("Enter Employee Salary");
		float salary = sc.nextFloat();
		System.out.println("Enter Employee year of joining");
		int doj = sc.nextInt();
		System.out.println("Enter Employee age");
		int age = sc.nextInt();

		sc.close();
		return constructEmployee(eid, num, name, salary, EmployeeUtil.getDate(doj), age);
	}

	static Employee constructEmployee(int eid, int num, String name, float salary, Date date, int age) {
		Employee emp = new Employee();
		emp.setEid(eid);
		emp.setNumber(num);
		emp.setName(name);
		emp.setSalary(salary);
		emp.setDoj(date);
		emp.setAge(age);
		return emp;

	}

	public static Double cal_DAandHRAandGrossSal(Employee emp) {
		float DA = 0, HRA = 0;
		if (emp.getSalary() < 10000) {
			DA = (emp.getSalary() * 0.08f);
			HRA = (emp.getSalary() * 0.15f);
			emp.setSalary(emp.getSalary() + DA + HRA);
		} else if (emp.getSalary() > 10000 && emp.getSalary() < 20000) {
			DA = (emp.getSalary() * 0.1f);
			HRA = (emp.getSalary() * 0.2f);
			emp.setSalary(emp.getSalary() + DA + HRA);
		} else if (emp.getSalary() > 20000 && emp.getSalary() < 30000 && emp.getAge() > 40) {
			DA = (emp.getSalary() * 0.15f);
			HRA = (emp.getSalary() * 0.27f);
			emp.setSalary(emp.getSalary() + DA + HRA);
		} else if (emp.getSalary() > 20000 && emp.getSalary() < 30000 && emp.getAge() < 40) {
			DA = (emp.getSalary() * 0.13f);
			HRA = (emp.getSalary() * 0.25f);
			emp.setSalary(emp.getSalary() + DA + HRA);
		} else {
			DA = (emp.getSalary() * 0.17f);
			HRA = (emp.getSalary() * 0.30f);
			emp.setSalary(emp.getSalary() + DA + HRA);
		}
		// System.out.println("DA of "+emp[i].getName()+" is " +DA);
		// System.out.println("HRA of "+emp[i].getName()+" is " +HRA);
		// System.out.println("Gross Salary of " +emp[i].getName()+" is
		// "+emp[i].getSalary());
		return (double) emp.getSalary();
	}


	public static void displayOptionsMenu() {
		System.out.println("\n" + "Please select your desired operation from below: ");

		System.out.println("1. Add Employee");
		System.out.println("2. Find Employee by Id");
		System.out.println("3. Find Employee by name");
		System.out.println("4. Update Employee");
		System.out.println("5. Calculate Gross salary");
		System.out.println("6. Display Employee list");
		System.out.println("7. Delete Employee");
		System.out.println("8. Exit");
		
	}
}
