package employeeArrayInterface;

public class InvalidSalaryException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	String s = "Salary should be greater than 5000";
	
	public InvalidSalaryException(String msg) {
		super(msg);
	}
	
}
