package employeeArrayInterface;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import classes.EmployeeUtil;

public class CollectionEmployeeUtil {
	
	private static Scanner sc = new Scanner(System.in);

	public static void populateCSVtoArraylist(IEmployeeArray cImpl) throws Exception {
		
		File file = new File("C:\\Users\\Sandeep Manchala\\Desktop\\Employee.csv");
		ArrayList<Employee> templist =((CollectionEmployeeOperations) cImpl).readEmployeesFromCSV(file);
		 for(Employee e: templist) {
				if(e!= null)
					cImpl.createEmployee(e);
		 }
	}
			

	public static Employee constructEmployee(int eid, int num, String name, Float sal, Date doj, int age) {
		Employee emp = new Employee();
		emp.setEid(eid);
		emp.setNumber(num);
		emp.setName(name);
		emp.setSalary(sal);
		emp.setDoj(doj);
		emp.setAge(age);
		return emp;
	}


	public static Employee readEmployee() {
		
		System.out.println("Enter Employee Id");
		int eid = sc.nextInt();
		System.out.println("Enter Employee Number");
		int num = sc.nextInt();
		System.out.println("Enter Employee Name");
		String name = sc.next();
		System.out.println("Enter Employee Salary");
		float salary = sc.nextFloat();
		System.out.println("Enter Employee year of joining");
		int doj = sc.nextInt();
		System.out.println("Enter Employee age");
		int age = sc.nextInt();

		return constructEmployee(eid, num, name, salary, EmployeeUtil.getDate(doj), age);
		
	}


	public static Employee getNewEmpDetails() {
		
		System.out.println("Enter Employee Id");
		int eid = sc.nextInt();
		System.out.println("Enter Employee Number");
		int num = sc.nextInt();
		System.out.println("Enter Employee Name");
		String name = sc.next();
		System.out.println("Enter Employee Salary");
		float salary = sc.nextFloat();
		System.out.println("Enter Employee year of joining");
		int doj = sc.nextInt();
		System.out.println("Enter Employee age");
		int age = sc.nextInt();

		return constructEmployee(eid, num, name, salary, EmployeeUtil.getDate(doj), age);
		
	}


	public static void displayMenu() {
		    System.out.println("\n" + "Please select your desired operation from below: ");

			System.out.println("1. Add Employee");
			System.out.println("2. Find Employee by Id");
			System.out.println("3. Find Employee by name");
			System.out.println("4. Update Employee");
			System.out.println("5. Calculate Gross salary");
			System.out.println("6. Display Employee list");
			System.out.println("7. Delete Employee");
			System.out.println("8. Sort Employees");
			System.out.println("9. Display by Unique Employee Names");
			System.out.println("10. Display Employee Age Range Count");
			System.out.println("11. Exit");
		
	}
	
}
