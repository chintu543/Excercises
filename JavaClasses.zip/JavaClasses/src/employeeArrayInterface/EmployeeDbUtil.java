package employeeArrayInterface;

import java.util.Date;
import java.util.Scanner;

import classes.EmployeeUtil;

public class EmployeeDbUtil {
	private static Scanner sc = new Scanner(System.in);

	public static Employee readEmployee() {
		
		System.out.println("Enter Employee Id");
		int eid = sc.nextInt();
		System.out.println("Enter Employee Number");
		int num = sc.nextInt();
		System.out.println("Enter Employee Name");
		String name = sc.next();
		System.out.println("Enter Employee Salary");
		float salary = sc.nextFloat();
		System.out.println("Enter Employee year of joining");
		int doj = sc.nextInt();
		System.out.println("Enter Employee age");
		int age = sc.nextInt();

		return constructEmployee(eid, num, name, salary, EmployeeUtil.getDate(doj), age);
		
	}

	private static Employee constructEmployee(int eid, int num, String name, float salary, Date date, int age) {
		
		Employee emp = new Employee();
		emp.setEid(eid);
		emp.setNumber(num);
		emp.setName(name);
		emp.setSalary(salary);
		emp.setDoj(date);
		emp.setAge(age);
		return emp;
		
	}
	
	
	

}
