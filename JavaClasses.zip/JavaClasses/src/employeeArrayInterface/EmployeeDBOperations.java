package employeeArrayInterface;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class EmployeeDBOperations implements IEmployeeArray {
	Connection con;
	PreparedStatement pStmt;

	EmployeeDBOperations() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_db", "root", "root123");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void createEmpTable() throws SQLException {

		pStmt = con.prepareStatement(
				"create table employee(id INT, empNo INT, name VARCHAR(45), salary DECIMAL, doj DATE, age INT,   PRIMARY KEY (id))");
		pStmt.executeUpdate();
		System.out.println("Table Employee is created");

	}

	@Override
	public void createEmployee(Employee e) throws InvalidSalaryException, SQLException {

		Date doj = new Date(e.getDoj().getTime());
		if (e.getSalary() < 5000) {
			throw new InvalidSalaryException("Salary should be greater than 5000");
		} else {

			pStmt = con
					.prepareStatement("insert into employee (id, empNo, name, salary, doj, age) values (?,?,?,?,?,?)");

			pStmt.setInt(1, e.getEid());
			pStmt.setInt(2, e.getNumber());
			pStmt.setString(3, e.getName());
			pStmt.setFloat(4, e.getSalary());
			pStmt.setDate(5, doj);
			pStmt.setInt(6, e.getAge());
			pStmt.executeUpdate();
		}
	}

	@Override
	public Employee findEmployee(int empId) throws SQLException {

		pStmt = con.prepareStatement("select * from employee where id = ?");
		pStmt.setInt(1, empId);
		ResultSet rs = pStmt.executeQuery();

		Employee emp = new Employee();

		while (rs.next()) {

			emp.setEid(rs.getInt(1));
			emp.setNumber(rs.getInt(2));
			emp.setName(rs.getString(3));
			emp.setSalary(rs.getFloat(4));
			emp.setDoj(rs.getDate(5));
			emp.setAge(rs.getInt(6));

		}
		return emp;
	}

	@Override
	public Employee findEmployee(String name) throws SQLException {

		pStmt = con.prepareStatement("select * from employee where name = ?");
		pStmt.setString(1, name);
		ResultSet rs = pStmt.executeQuery();

		Employee emp = new Employee();

		while (rs.next()) {
			emp.setEid(rs.getInt(1));
			emp.setNumber(rs.getInt(2));
			emp.setName(rs.getString(3));
			emp.setSalary(rs.getFloat(4));
			emp.setDoj(rs.getDate(5));
			emp.setAge(rs.getInt(6));
		}
		return emp;
	}

	@Override
	public boolean deleteEmployee(int empId) throws EmployeeNotFoundException, SQLException {

		pStmt = con.prepareStatement("delete from employee where id = ?");
		pStmt.setInt(1, empId);
		int val = pStmt.executeUpdate();
		System.out.println(val);

		if (val == 0) {
			throw new EmployeeNotFoundException("No Employee found with the given id value");
		}
		return true;
	}

	@Override
	public boolean updateEmployee(Employee e) throws EmployeeNotFoundException, SQLException {

		Date doj = new Date(e.getDoj().getTime());

		pStmt = con.prepareStatement("update employee set empNo= ?, name= ?, salary= ?, doj= ?, age=? where id= ?");
		pStmt.setInt(1, e.getNumber());
		pStmt.setString(2, e.getName());
		pStmt.setFloat(3, e.getSalary());
		pStmt.setDate(4, doj);
		pStmt.setInt(5, e.getAge());
		pStmt.setInt(6, e.getEid());
		int val = pStmt.executeUpdate();

		if (val == 0) {
			throw new EmployeeNotFoundException("No Employee found with the given id value");
		}

		return true;
	}

	@Override
	public Double calculateGrossSal(int empId) throws SQLException {

		pStmt = con.prepareStatement("select * from employee where id = ?");
		pStmt.setInt(1, empId);
		ResultSet rs = pStmt.executeQuery();

		Employee emp = new Employee();

		while (rs.next()) {
			emp.setEid(rs.getInt(1));
			emp.setNumber(rs.getInt(2));
			emp.setName(rs.getString(3));
			emp.setSalary(rs.getFloat(4));
			emp.setDoj(rs.getDate(5));
			emp.setAge(rs.getInt(6));
		}

		return EmployeeArrayUtil.cal_DAandHRAandGrossSal(emp);
	}

	public void displayEmployee() throws SQLException {

		pStmt = con.prepareStatement("select * from employee");
		ResultSet rs = pStmt.executeQuery();

		Employee emp = new Employee();

		while (rs.next()) {
			emp.setEid(rs.getInt(1));
			emp.setNumber(rs.getInt(2));
			emp.setName(rs.getString(3));
			emp.setSalary(rs.getFloat(4));
			emp.setDoj(rs.getDate(5));
			emp.setAge(rs.getInt(6));
			System.out.println(emp);
		}

	}

	public void sortEmployees() throws SQLException {

		System.out.println("Press from below" + "\n" + "1. To Sort Employees by Name" + "\n"
				+ "2. To Sort by Employees by age and salary");
		Scanner sc = new Scanner(System.in);
		int c = sc.nextInt();
		switch (c) {
		case 1:
			pStmt = con.prepareStatement("select * from employee order by name");
			ResultSet rs = pStmt.executeQuery();
			Employee emp = new Employee();
			while (rs.next()) {
				emp.setEid(rs.getInt(1));
				emp.setNumber(rs.getInt(2));
				emp.setName(rs.getString(3));
				emp.setSalary(rs.getFloat(4));
				emp.setDoj(rs.getDate(5));
				emp.setAge(rs.getInt(6));
				System.out.println(emp);
			}
			break;
		case 2:
			pStmt = con.prepareStatement("select * from employee order by age DESC, salary DESC");
			ResultSet r = pStmt.executeQuery();
			Employee e = new Employee();
			while (r.next()) {
				e.setEid(r.getInt(1));
				e.setNumber(r.getInt(2));
				e.setName(r.getString(3));
				e.setSalary(r.getFloat(4));
				e.setDoj(r.getDate(5));
				e.setAge(r.getInt(6));
				System.out.println(e);
			}
			break;

		}
		sc.close();
	}

	public void displayUniqueNames() throws SQLException {
		pStmt = con.prepareStatement("select DISTINCT name from employee");
		ResultSet rs = pStmt.executeQuery();
		Employee emp = new Employee();
		while (rs.next()) {
			System.out.println(rs.getString(1));
		}

	}

	public void displayAgeRangeCount() throws SQLException {

		pStmt = con.prepareStatement("select COUNT(*) from employee where age BETWEEN 20 AND 30 ");
		ResultSet rs1 = pStmt.executeQuery();

		pStmt = con.prepareStatement("select COUNT(*) from employee where age BETWEEN 30 AND 40 ");
		ResultSet rs2 = pStmt.executeQuery();

		pStmt = con.prepareStatement("select COUNT(*) from employee where age BETWEEN 40 AND 50 ");
		ResultSet rs3 = pStmt.executeQuery();

		pStmt = con.prepareStatement("select COUNT(*) from employee where age BETWEEN 50 AND 60 ");
		ResultSet rs4 = pStmt.executeQuery();

		while (rs1.next()) {
			System.out.println("Total Employees in Age Range 20-30 is " + rs1.getInt(1));
		}

		while (rs2.next()) {
			System.out.println("Total Employees in Age Range 30-40 is " + rs2.getInt(1));
		}

		while (rs3.next()) {
			System.out.println("Total Employees in Age Range 40-50 is " + rs3.getInt(1));
		}

		while (rs4.next()) {
			System.out.println("Total Employees in Age Range 50-60 is " + rs4.getInt(1));
		}

	}

	public void dropEmpTable() throws SQLException {

		pStmt = con.prepareStatement("Drop table employee");
		pStmt.executeUpdate();
		System.out.println("Table Employees is dropped");

	}

}
