package employeeArrayInterface;

import java.util.Comparator;
import java.util.Date;

public class Employee implements Comparable<Employee>{

	private int eid;
	private int number;
	private String name;
	private float salary;
	private Date doj;
	private int age;
	

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", number=" + number + ", name=" + name + ", salary=" + salary + ", doj=" + doj
				+ ", age=" + age + "]";
	}

	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getHRA() {
		return (salary*20)/100;
	}

	@Override
	public int compareTo(Employee e) {
	     
		if(name.compareTo(e.name) > 0)
			return 1;
		if(name.compareTo(e.name) < 0)
			return -1;
		
		return 0;
	}
		
}

class EmployeeByAgeandSalary implements Comparator<Employee>{

	@Override
	public int compare(Employee e1, Employee e2) {
		
		if(e1.getAge() > e2.getAge())
			return -1;
		if(e1.getAge() < e2.getAge())
			return 1;
		
		if(e1.getSalary() > e2.getSalary())
			return -1;
		if(e1.getSalary() < e2.getSalary())
			return 1;
		
		return 0;
	}
	
}


//public Employee constructEmployee(int eid, int number, String name, float salary, Date doj, int age ) {
//Employee emp = new Employee();
//emp.setId(eid);
//emp.setNumber(number);
//emp.setName(name);
//emp.setSalary(salary);
//emp.setDoj(doj);
//emp.setage(age);
//return emp;
//}
