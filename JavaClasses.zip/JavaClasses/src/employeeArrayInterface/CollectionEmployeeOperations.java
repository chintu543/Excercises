package employeeArrayInterface;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import classes.EmployeeUtil;

public class CollectionEmployeeOperations implements IEmployeeArray {

	List<Employee> empList = new ArrayList<Employee>();

	@Override
	public void createEmployee(Employee e) throws InvalidSalaryException {
		if (e.getSalary() < 5000) {
			throw new InvalidSalaryException("Salary should be greater than 5000");
		} else
			empList.add(e);
	}

	@Override
	public Employee findEmployee(int empId) {
		for (Employee e : empList) {
			if (e.getEid() == empId)
				return e;
		}
		return null;
	}

	@Override
	public Employee findEmployee(String name) {
		for (Employee e : empList) {
			if (e.getName().equals(name))
				return e;
		}
		return null;
	}

	@Override
	public boolean deleteEmployee(int empId) throws EmployeeNotFoundException {
		boolean b = false;
		for (int i = 0; i < empList.size(); i++) {
			if (empList.get(i).getEid() == empId) {
				b = true;
				empList.remove(empList.get(i));
			}
		}
		if (b == false) {
			throw new EmployeeNotFoundException("No Employee found with the given id value");
		}
		return true;
	}

	@Override
	public boolean updateEmployee(Employee e) throws EmployeeNotFoundException {
		int val = 0;
		boolean b = false;
		for (int i = 0; i < empList.size(); i++) {
			if (empList.get(i).getEid() == e.getEid()) {
				val = i;
				b = true;
			}
		}

		if (b == false) {
			throw new EmployeeNotFoundException("No Employee found with the given id value");
		}

		if (b == true) {
			empList.get(val).setEid(e.getEid());
			empList.get(val).setNumber(e.getNumber());
			empList.get(val).setName(e.getName());
			empList.get(val).setSalary(e.getSalary());
			empList.get(val).setDoj(e.getDoj());
			empList.get(val).setAge(e.getAge());

		}

		return true;

	}

	@Override
	public Double calculateGrossSal(int empId) {
		Employee em = new Employee();
		for (Employee e : empList) {
			if (e.getEid() == empId)
				em = e;
		}
		return EmployeeArrayUtil.cal_DAandHRAandGrossSal(em);
	}

	public ArrayList<Employee> readEmployeesFromCSV(File file) throws Exception {

		ArrayList<Employee> emp = new ArrayList<Employee>();
		Reader fr = null;
		BufferedReader br = null;

		try {
			File inFile = file;

			fr = new FileReader(inFile);
			br = new BufferedReader(fr);

			String line = null;

			boolean keepReading = true;

			int index = 0;
			while (keepReading) {
				line = br.readLine();

				if (line == null || line.equals("")) {
					break;
				}
				if (index != 0) {
					Employee e = parseLine(line);
					emp.add(e);
				}

				index++;
			}

		} finally {
			br.close();
			fr.close();
		}

		return emp;
	}

	private Employee parseLine(String line) {
		String[] tokens = line.split(",");
		int eid = Integer.parseInt(tokens[0]);
		int num = Integer.parseInt(tokens[1]);
		String name = tokens[2];
		Float sal = Float.parseFloat(tokens[3]);
		Date doj = EmployeeUtil.getDate(Integer.parseInt(tokens[4]));
		int age = Integer.parseInt(tokens[5]);

		Employee emp = CollectionEmployeeUtil.constructEmployee(eid, num, name, sal, doj, age);
		return emp;
	}

	public void displayEmployee() {
		for (Employee e : empList) {
			System.out.println(e);
		}

	}

	public void writeToFile() throws IOException {

		String Comma_Delimiter = ",";
		String New_Line_Seperator = "\n";
		String File_Header = "eid,number,name,salary,Doj,Age";

		FileWriter filewriter = new FileWriter("C:\\Users\\Sandeep Manchala\\Desktop\\EmpData.csv");
		filewriter.append(File_Header);
		for (Employee e : empList) {
			if (e != null) {
				filewriter.append(New_Line_Seperator);
				filewriter.append(String.valueOf(e.getEid()));
				filewriter.append(Comma_Delimiter);
				filewriter.append(String.valueOf(e.getNumber()));
				filewriter.append(Comma_Delimiter);
				filewriter.append(e.getName());
				filewriter.append(Comma_Delimiter);
				filewriter.append(String.valueOf(e.getSalary()));
				filewriter.append(Comma_Delimiter);
				filewriter.append(String.valueOf(e.getDoj()));
				filewriter.append(Comma_Delimiter);
				filewriter.append(String.valueOf(e.getAge()));
				filewriter.append(Comma_Delimiter);
			}
		}

		filewriter.flush();
		filewriter.close();
	}

	public void sort() {
		System.out.println("Press from below" + "\n" + "1. To Sort Employees by Name" + "\n"
				+ "2. To Sort by Employees by age and salary");
		Scanner sc = new Scanner(System.in);
		int c = sc.nextInt();
		switch (c) {
		case 1:
			Collections.sort(empList);
			System.out.println("Employees after sorting by Name: ");
			displayEmployee();
			break;
		case 2:
			Collections.sort(empList, new EmployeeByAgeandSalary());
			System.out.println("Employees after sorting by Age and Salary: ");
			displayEmployee();
			break;
		}
		sc.close();
	}

	public void displayUniqueNames() {
		Set<String> s = new TreeSet<String>();

		for (int i = 0; i < empList.size(); i++) {
			s.add(empList.get(i).getName());
		}
		System.out.println(s);
	}

	public void displayAgeRangeCount() {
		int c1 = 0, c2 = 0, c3 = 0, c4 = 0;

		for (int i = 0; i < empList.size(); i++) {
			if (empList.get(i).getAge() > 20 && empList.get(i).getAge() <= 30)
				c1++;
			else if (empList.get(i).getAge() > 30 && empList.get(i).getAge() <= 40)
				c2++;
			else if (empList.get(i).getAge() > 40 && empList.get(i).getAge() <= 50)
				c3++;
			else if (empList.get(i).getAge() > 50 && empList.get(i).getAge() <= 60)
				c4++;
		}
		System.out.println("Total Employees in Age Range 21-30 is " + c1);
		System.out.println("Total Employees in Age Range 31-40 is " + c2);
		System.out.println("Total Employees in Age Range 41-50 is " + c3);
		System.out.println("Total Employees in Age Range 51-60 is " + c4);

	}

}
