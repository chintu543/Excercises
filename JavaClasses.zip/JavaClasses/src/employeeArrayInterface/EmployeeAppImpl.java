package employeeArrayInterface;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.util.Date;

import classes.EmployeeUtil;

public class EmployeeAppImpl implements IEmployeeArray {

	private Employee[] emp = null;

	private int i = 0;
	private int arrSize;
	private int size;

	public EmployeeAppImpl(int arrSize) {
		super();
		this.arrSize = arrSize;
		emp = new Employee[arrSize];
	}

	public void displayEmployee() {
		for (int i = 0; i < size; i++) {
			System.out.println(emp[i]);
		}

	}

	public void createEmployee(Employee e) throws InvalidSalaryException {
		if (e.getSalary() < 5000) {
			throw new InvalidSalaryException("Salary should be greater than 5000");

		}
		emp[i] = e;
		i++;
		size++;

	}

	public Employee findEmployee(int empid) {
		return emp[empid - 1];

	}

	@Override
	public Employee findEmployee(String name) {
		int id = 0;
		for (int i = 0; i < size; i++) {
			if (emp[i].getName().equals(name))
				id = i;
		}
		return (emp[id]);
	}

	@Override
	public boolean deleteEmployee(int empId) throws EmployeeNotFoundException {
		boolean val = false;

		for (int i = 0; i < size; i++) {
			if (emp[i] != null) {
				if (emp[i].getEid() == empId) {
					val = true;
					for (int j = i; j < size; j++) {
						emp[j] = emp[j + 1];
					}
					if (val == false) {
						throw new EmployeeNotFoundException("No Employee found with the given id value");
					}
				}
			}
		}
		return true;
	}

	@Override
	public boolean updateEmployee(Employee e) throws EmployeeNotFoundException {
		boolean val = false;
		for (int i = 0; i < size; i++) {
			if (emp[i].getEid() == e.getEid()) {
				val = true;
			}
		}

		if (val == false) {
			throw new EmployeeNotFoundException("No Employee found with the given id value");
		} else {
			for (int i = 0; i < size; i++) {
				if (emp[i].getEid() == e.getEid()) {
					emp[i].setEid(e.getEid());
					emp[i].setNumber(e.getNumber());
					emp[i].setName(e.getName());
					emp[i].setSalary(e.getSalary());
					emp[i].setDoj(e.getDoj());
					emp[i].setAge(e.getAge());

				}
			}

			emp[e.getEid() - 1] = e;
			return false;
		}
	}

	@Override
	public Double calculateGrossSal(int empId) {
		Employee em = new Employee();
		for (int i = 0; i < size; i++) {
			if (emp[i].getEid() == empId)
				em = emp[i];
		}
		return EmployeeArrayUtil.cal_DAandHRAandGrossSal(em);

	}

	public Employee[] readEmployeesFromCSV(File file) throws Exception {

		emp = new Employee[arrSize];
		Reader fr = null;
		BufferedReader br = null;

		try {
			File inFile = file;

			fr = new FileReader(inFile);
			br = new BufferedReader(fr);

			String line = null;

			boolean keepReading = true;

			int index = 0;
			while (keepReading) {
				line = br.readLine();

				if (line == null || line.equals("")) {
					break;
				}
				if (index != 0) {
					Employee e = parseLine(line);
					emp[index - 1] = e;
				}

				index++;
			}

		} finally {
			br.close();
			fr.close();
		}

		return emp;
	}

	private Employee parseLine(String line) {
		String[] tokens = line.split(",");
		int eid = Integer.parseInt(tokens[0]);
		int num = Integer.parseInt(tokens[1]);
		String name = tokens[2];
		Float sal = Float.parseFloat(tokens[3]);
		Date doj = EmployeeUtil.getDate(Integer.parseInt(tokens[4]));
		int age = Integer.parseInt(tokens[5]);

		Employee emp = EmployeeArrayUtil.constructEmployee(eid, num, name, sal, doj, age);
		return emp;
	}

	public void writeToFile() throws Exception {

		String Comma_Delimiter = ",";
		String New_Line_Seperator = "\n";
		String File_Header = "eid,number,name,salary,Doj,Age";

		FileWriter filewriter = new FileWriter("C:\\Users\\Sandeep Manchala\\Desktop\\EmpData.csv");
		filewriter.append(File_Header);
		for (Employee e : emp) {
			if (e != null) {
				filewriter.append(New_Line_Seperator);
				filewriter.append(String.valueOf(e.getEid()));
				filewriter.append(Comma_Delimiter);
				filewriter.append(String.valueOf(e.getNumber()));
				filewriter.append(Comma_Delimiter);
				filewriter.append(e.getName());
				filewriter.append(Comma_Delimiter);
				filewriter.append(String.valueOf(e.getSalary()));
				filewriter.append(Comma_Delimiter);
				filewriter.append(String.valueOf(e.getDoj()));
				filewriter.append(Comma_Delimiter);
				filewriter.append(String.valueOf(e.getAge()));
				filewriter.append(Comma_Delimiter);
			}
		}

		filewriter.flush();
		filewriter.close();
	}

}
