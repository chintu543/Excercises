package employeeArrayInterface;

import java.sql.SQLException;
import java.util.Scanner;

public class EmployeeDatabaseApp {

	public static void main(String[] args) throws InvalidSalaryException, SQLException {

		databaseOperations();

	}

	private static void databaseOperations() throws SQLException {

		Scanner sc = new Scanner(System.in);

		IEmployeeArray dbImpl = new EmployeeDBOperations();

		do {
			displayMenu();
			int c = sc.nextInt();
			switch (c) {
			case 0:
				((EmployeeDBOperations) dbImpl).createEmpTable();
				break;
			case 1:
				try {
					dbImpl.createEmployee(EmployeeDbUtil.readEmployee());
				} catch (InvalidSalaryException ex) {
					System.out.println(ex);
				}
				break;
			case 2:
				System.out.println("please enter the id to find employee");
				int empid = sc.nextInt();
				System.out.println(dbImpl.findEmployee(empid));
				break;
			case 3:
				System.out.println("Please enter the name to find employee");
				String name = sc.next();
				System.out.println(dbImpl.findEmployee(name));
				break;
			case 4:
				System.out.println("Please enter employee id you want to update");
				int id = sc.nextInt();
				try {
					dbImpl.updateEmployee(CollectionEmployeeUtil.getNewEmpDetails());
				} catch (EmployeeNotFoundException ex) {
					System.out.println(ex);
				}
				break;
			case 5:
				System.out.println("Please enter employee id to get Gross Salary");
				int eid = sc.nextInt();
				System.out.println("Gross Salary of given employee id is: " + dbImpl.calculateGrossSal(eid));
				break;
			case 6:
				System.out.println("Enter employee id you wanna delete");
				int Id = sc.nextInt();
				try {
					dbImpl.deleteEmployee(Id);
					System.out.println("Employee is deleted!!");
				} catch (EmployeeNotFoundException ex) {
					System.out.println(ex);
				}
				break;
			case 7:
				((EmployeeDBOperations) dbImpl).displayEmployee();
				break;
			case 8:
				((EmployeeDBOperations) dbImpl).sortEmployees();
				break;
			case 9:
				((EmployeeDBOperations) dbImpl).displayUniqueNames();
				break;
			case 10:
				((EmployeeDBOperations) dbImpl).displayAgeRangeCount();
				break;
			case 11:
				((EmployeeDBOperations) dbImpl).dropEmpTable();
				break;
			case 12:
				System.exit(0);
			}
			
			sc.close();
			
		} while (true);

	}

	private static void displayMenu() {
		System.out.println("\n" + "Please select your desired operation from below: ");

		System.out.println("0. Create a Table");
		System.out.println("1. Add Employee");
		System.out.println("2. Find Employee by Id");
		System.out.println("3. Find Employee by name");
		System.out.println("4. Update Employee");
		System.out.println("5. Calculate Gross salary");
		System.out.println("6. Delete Employee");
		System.out.println("7. Display Employee list");
		System.out.println("8. Sort Employees");
		System.out.println("9. Display by Unique Employee Names");
		System.out.println("10. Display Employee Age Range Count");
		System.out.println("11. Drop Table");
		System.out.println("12. Exit");

	}

}
