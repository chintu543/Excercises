package employeeArrayInterface;

public class EmployeeNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	String s = "Employee not found with given ID";
	
	public EmployeeNotFoundException(String msg) {
		super(msg);
	}

	 
	
}
