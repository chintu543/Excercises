package employeeArrayInterface;

import java.util.Scanner;

public class EmployeeArrayApp {

	public static void main(String[] args) throws Exception {

		arrayOperations();

	}

	private static void arrayOperations() throws Exception {

		System.out.println("Please enter the number of Employee you want to work on");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		IEmployeeArray eImpl = new EmployeeAppImpl(n);

		EmployeeArrayUtil.populateCSVtoArray((EmployeeAppImpl) eImpl);

		System.out.println("\n" + "Imported values from CSV file");

		do {
			EmployeeArrayUtil.displayOptionsMenu();
			int c = sc.nextInt();
			switch (c) {

			case 1:
				eImpl.createEmployee(EmployeeArrayUtil.readEmployee());
				break;
			case 2:
				System.out.println("please enter the id to find employee");
				int empid = sc.nextInt();
				System.out.println(eImpl.findEmployee(empid));
				break;
			case 3:
				System.out.println("Please enter the name to find employee");
				String name = sc.next();
				System.out.println(eImpl.findEmployee(name));
				break;
			case 4:
				System.out.println("Please enter employee id you want to update");
				int id = sc.nextInt();
				eImpl.updateEmployee(EmployeeArrayUtil.getNewEmpDetails());
				break;
			case 5:
				System.out.println("Please enter employee id to get Gross Salary");
				int eid = sc.nextInt();
				System.out.println("Gross Salary of given employee id is: " + eImpl.calculateGrossSal(eid));
				break;
			case 6:
				((EmployeeAppImpl) eImpl).displayEmployee();
				break;
			case 7:
				System.out.println("Enter employee id you wanna delete");
				int Id = sc.nextInt();
				eImpl.deleteEmployee(Id);
				System.out.println("Employee is deleted!!");
				break;
			case 8:
				((EmployeeAppImpl) eImpl).writeToFile();
				return;
			}
			
			sc.close();

		} while (true);

	}

}
