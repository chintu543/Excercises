package Java;

import java.util.Scanner;

public class SimpleInterest {

	public static void main(String[] args) {
		
		float principle, rate, time;
		
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the Principle value");
		principle = s.nextFloat();
		
		System.out.println("Enter the rate value");
		rate = s.nextFloat();
		
		System.out.println("Enter the year value");
		time = s.nextFloat();
		
		float Simpleinterest = (principle*rate*time)/100;
		
		System.out.println("Simple Interest value is " +Simpleinterest);
		s.close();
	}

}
