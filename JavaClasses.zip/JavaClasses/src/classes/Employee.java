package classes;

import java.util.Date;

public class Employee {
	
	private int eid;
	private int number;
	private String name;
	private float salary;
	private Date doj;
	private int Age;
	
	private static String Company_Name;
	
	{
	  salary = 10000;
	}
	
	static {
		Company_Name="XYZ Comp";
	}
	
	public static String getCompanyName() {
		return Company_Name;
	}
	
	
	
	public int getId() {
		return eid;
	}
	public void setId(int eid) {
		this.eid = eid;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", number=" + number + ", name=" + name + ", salary=" + salary + ", doj=" + doj
				+ ", Age=" + Age + "]";
	}
	
	public Employee constructEmployee(int eid, int number, String name, float salary, Date doj, int Age ) {
		Employee emp = new Employee();
		emp.setId(eid);
		emp.setNumber(number);
		emp.setName(name);
		emp.setSalary(salary);
		emp.setDoj(doj);
		emp.setAge(Age);
		return emp;
	}
	
	
	public float getHRA() {
		return (salary*20)/100;
	}
	

}
