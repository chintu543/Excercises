package classes;


public enum DeptEnum {
	
	SALES(10),
	PURCHASE(20),
	ADMINISTRATION(30),
	RESEARCH(40),
	
	UNKNOWN_DEPT(-1);
	 
	int val;
	
	private DeptEnum(int val) {
		this.val = val;
	}

	public static DeptEnum getType(int val) {
		for (DeptEnum DeptEnm : DeptEnum.values()) {
			if (DeptEnm.val == val) {
				return DeptEnm;
			}
		}
		
		return UNKNOWN_DEPT;
	}

}
