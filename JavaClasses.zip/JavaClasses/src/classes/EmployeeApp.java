package classes;

import java.util.Scanner;

public class EmployeeApp {

	public static void main(String[] args) {
		
		Employee e = new Employee();
		e = e.constructEmployee(101, 15461, "Jimmy", 4500f, EmployeeUtil.getDate(2016), 27);
		System.out.println(e);
		System.out.println("HRA of " +e.getName() + " is " +e.getHRA());
		
		Employee e2 = new Employee();
		e2 = e2.constructEmployee(102, 16164, "Aditya", 12000f, EmployeeUtil.getDate(2014), 46);
		EmployeeUtil.displayEmployeeInfo(e2);
		System.out.println("Highest Salary Employee is " +EmployeeUtil.gethighestSalaryEmp(e, e2));
		System.out.println(EmployeeUtil.constructEmp(e2));
		System.out.println("Older Employee is " +EmployeeUtil.getOlderEmp(e, e2));
	    System.out.println("Updated Salary is " +EmployeeUtil.updateEmpSal(e2));
	    System.out.println(e2);
	    EmployeeUtil.cal_DAandHRAandGrossSal(e2);
	    
		
		Employee e3 = new Employee();
		e3 = e3.constructEmployee(103, 16544, "Rajat", 11000f, EmployeeUtil.getDate(2013), 25);
		EmployeeUtil.displayEmployeeInfo(e3);
		EmployeeHelper helper = new EmployeeHelper(e3);
		helper.increaseSalary(e3);
		helper.getService(e3);
		helper.getseniorEmp(e3, e2);
		
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Employee value: ");
		int val = s.nextInt();
		
		System.out.println(DeptEnum.getType(val));
		
		s.close();
	}

}
