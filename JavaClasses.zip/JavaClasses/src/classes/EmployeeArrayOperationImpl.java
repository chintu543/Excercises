package classes;

import java.util.Date;
import java.util.Scanner;


public class EmployeeArrayOperationImpl {
	
	int size, i=0;
	int d = 0,k,j,n;
	int a=0;
	
	Scanner s = new Scanner(System.in);
	
	Employee []emp = null;
	
	public EmployeeArrayOperationImpl(int size) {
		this.size = size;
		emp = new Employee[size];
		
	}

	  public Employee addEmployee(int eid, int num, String name, float salary, Date doj, int age) {
		  Employee emp = new Employee();
			emp.setId(eid);
			emp.setNumber(num);
			emp.setName(name);
			emp.setSalary(salary);
			emp.setDoj(doj);
			emp.setAge(age);
			return emp;
	}
	  
	  public void displayEmployee() {
		  for(int i=0; i<size; i++) {
			  System.out.println(emp[i]);
		  }
		  
	  }
	  	
	  public void displayEmployeebyID(int id)
	  {
		  for(int i=0; i<size; i++) {
			  if(emp[i].getId()==id)
			   System.out.println(emp[i]); 
		  }
	  }
	

	public void updateEmployee(int id, int num, String name, float sal, Date doj, int age) {
		for(int i=0; i<size; i++) {
			  if(emp[i].getId()==id) {
					emp[i].setNumber(num);
					emp[i].setName(name);
					emp[i].setSalary(sal);
					emp[i].setDoj(doj);
					emp[i].setAge(age);		  
			  }
			  
		}
		
	}

	public void displaySelectedEmpHRA(int id) {
		for(int i=0; i<size; i++) {
			  if(emp[i].getId()==id)
			   System.out.println("HRA of " +emp[i].getName() +"is " +emp[i].getHRA());
		}
	}

	
	public void displaySelectedEmpGrossSalary(int id) {
		Employee em = new Employee();
		for(int i=0; i<size; i++) {
			  if(emp[i].getId()==id) {
				  em = emp[i];
				  EmployeeHelper helper = new EmployeeHelper(em);
				  helper.cal_DAandHRAandGrossSalary(em);
			  } 
		}
	}

	public void deleteEmployeebyID(int id) {
	
		 for(int i=0; i<size-1; i++) {           
			  if(emp[i].getId()==id) { 
				  d=i;
			  }   
		  }
				 k= d+1;
				 n= size;
				 j=k;
			     while(j<n) {
				 emp[j-1]=emp[j];
				 j = j+1;
			 }
			 n=n-1;
			 size = n;
	}

	
//	public void insertEmployee(Employee e) {
//		    int i = a;
//			emp[i] = e;
//			a++;
//		
//	}
	
public void readEmployee() {
		
		Employee em = new Employee();
		System.out.println("Enter the Employee input values");
		for(int i=0; i<size; i++) {
				
			System.out.println("Enter Employee Id");
			int eid = s.nextInt();
			System.out.println("Enter Employee Number");
			int num = s.nextInt();
			System.out.println("Enter Employee Name");
			String name = s.next();
			System.out.println("Enter Employee Salary");
			float salary = s.nextFloat();
			System.out.println("Enter Employee year of joining");
			int doj = s.nextInt();
			System.out.println("Enter Employee age");
			int Age = s.nextInt();
			
			emp[i] = em.constructEmployee(eid, num, name, salary,EmployeeUtil.getDate(doj), Age);
		}

		
	}

	public boolean updateEmployee(Employee e) {
		for (int i =0; i<size; i++) {
			if(emp[i].getId()==e.getId() ) {
				emp[i] = e;	
			return true;	
			}
		}
		return false;
		
	}

	

}

