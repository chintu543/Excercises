package classes;

import java.util.Scanner;

public class EmployeeOperationsApp {

	public static void main(String[] args) {

		int size;
		Scanner s = new Scanner(System.in);
		System.out.println("how many employee you wanna enter?");
		size = s.nextInt();

		EmployeeArrayOperationImpl empImp = new EmployeeArrayOperationImpl(size);

		empImp.readEmployee();

		empImp.displayEmployee();

		System.out.println("Enter the id value to display employee");
		int id = s.nextInt();
		empImp.displayEmployeebyID(id);

		System.out.println("Enter the id value to update employee");
		id = s.nextInt();
		System.out.println("Enter new employee number");
		int num = s.nextInt();
		System.out.println("Enter new employee name");
		String name = s.next();
		System.out.println("Enter new employee salary");
		float sal = s.nextFloat();
		System.out.println("Enter Employee year of joining");
		int doj = s.nextInt();
		System.out.println("Enter Employee age");
		int age = s.nextInt();

		empImp.updateEmployee(id, num, name, sal, EmployeeUtil.getDate(doj), age);
		empImp.displayEmployee();

		System.out.println("Enter employee id to display it's HRA");
		id = s.nextInt();
		empImp.displaySelectedEmpHRA(id);

		System.out.println("Enter Employee id to display it's Gross Salary");
		id = s.nextInt();
		empImp.displaySelectedEmpGrossSalary(id);

		System.out.println("Enter Employee id which you need to delete");
		id = s.nextInt();
		empImp.deleteEmployeebyID(id);

		empImp.displayEmployee();

		s.close();
	}

}
