package classes;

import java.util.Calendar;
import java.util.Date;

public class EmployeeUtil {

	public static void displayEmployeeInfo(Employee e) {
		System.out.println(e);
		System.out.println("HRA of " +e.getName() + " is " +e.getHRA()); 	
	}
	
	public static Date getDate(int year) {
		Calendar cal =  Calendar.getInstance();
		cal.set(Calendar.YEAR, year);
		return cal.getTime();
	}
	
	public static String gethighestSalaryEmp(Employee e, Employee e2) {
		return (e.getSalary() > e2.getSalary()) ? e.getName() : e2.getName();
	}
	
	public static Employee constructEmp(Employee e) {
		Employee emp = new Employee();
		emp = e;
		return emp;
	}
	
	public static String getOlderEmp(Employee e, Employee e2) {
		return (e.getAge() > e2.getAge()) ? e.getName(): e2.getName();
	}
	
	public static float updateEmpSal(Employee e) {
		if (e.getAge() > 35 && e.getAge()<45 && e.getSalary() < 10000) {
			e.setSalary(e.getSalary() + e.getSalary() * 0.15f);
		} else if (e.getAge() > 45 && e.getAge() < 55 && e.getSalary() < 15000) {
			e.setSalary(e.getSalary() + e.getSalary() * 0.2f);
		} else if (e.getAge() > 55 && e.getSalary() < 20000) {
			e.setSalary(e.getSalary() + e.getSalary() * 0.25f);
		}
		return e.getSalary();
	}
	
	public static void cal_DAandHRAandGrossSal(Employee e) {
	float DA, HRA;
	if(e.getSalary() < 10000) {
		DA =  (e.getSalary() * 0.08f);
		HRA = (e.getSalary() * 0.15f);
	    e.setSalary(e.getSalary() + DA + HRA);
	}else if (e.getSalary() >10000 && e.getSalary() < 20000) {
		DA =  (e.getSalary() * 0.1f);
		HRA = (e.getSalary() * 0.2f);
	    e.setSalary(e.getSalary() + DA + HRA);
	}else if(e.getSalary() >20000 && e.getSalary() < 30000 && e.getAge() > 40 ) {
		DA =  (e.getSalary() * 0.15f);
		HRA = (e.getSalary() * 0.27f);
	    e.setSalary(e.getSalary() + DA + HRA);
	}else if(e.getSalary() >20000 && e.getSalary() < 30000 && e.getAge() < 40) {
		DA =  (e.getSalary() * 0.13f);
		HRA = (e.getSalary() * 0.25f);
	    e.setSalary(e.getSalary() + DA + HRA);
	}else  {
		DA =  (e.getSalary() * 0.17f);
	    HRA = (e.getSalary() * 0.30f);
        e.setSalary(e.getSalary() + DA + HRA);
	}
	    System.out.println("DA of "+e.getName()+" is " +DA);
	    System.out.println("HRA of "+e.getName()+" is " +HRA);
	    System.out.println("Gross Salary of " +e.getName()+" is "+e.getSalary());
	}
	
	
}
