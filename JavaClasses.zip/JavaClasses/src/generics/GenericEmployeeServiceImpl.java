package generics;

import employeeArrayInterface.Employee;

public class GenericEmployeeServiceImpl implements IGenericEmployeeServiceImpl {

	@Override
	public void addEmployee(Employee employee) {
		
	}

	@Override
	public Employee selectEmployee(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return false;
	}

}
