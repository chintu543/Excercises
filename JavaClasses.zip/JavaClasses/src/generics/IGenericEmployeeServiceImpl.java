package generics;

import employeeArrayInterface.Employee;

public interface IGenericEmployeeServiceImpl {
	
	public void addEmployee(Employee employee);
	
	public Employee selectEmployee(int empId);
	
	boolean deleteEmployee(int empId);
	
	boolean updateEmployee(Employee employee);

}
