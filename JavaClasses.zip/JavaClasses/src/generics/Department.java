package generics;

import lombok.Data;

/*@Getter
@Setter*/
@Data
public class Department {

	int deptNo;
	String deptName;
	String location;
	
	
}
