package threads;

import java.io.File;


public class FileLoader implements Runnable {

	private File fileName;

	public FileLoader() {
		
	}
	
	public FileLoader(File fileName2) {
		super();
		this.fileName = fileName2;
	}

	@Override
	public void run() {
		
		FiletoDBReader fl = new FiletoDBReader();
		try {
			fl.loadfileintoDB(fileName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
