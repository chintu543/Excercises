package threads;

import java.io.File;

public class BatchApp {

	public static void main(String[] args) {
		
		File[] files = readfilesintoFileArray();
		
		FileLoaderTaskExecutor fileLoaderTaskExecutor = new FileLoaderTaskExecutor();
		fileLoaderTaskExecutor.processFiles(files);
		

	}

	private static File[] readfilesintoFileArray() {
		
		File folder = new File("C:\\Users\\Sandeep Manchala\\Downloads\\Files");
        File[] files = folder.listFiles();
    
		return files;
			
		 
		}
	
			
		
	}


