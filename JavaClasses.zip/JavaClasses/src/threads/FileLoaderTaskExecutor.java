package threads;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class FileLoaderTaskExecutor {

	public void processFiles(File[] files) {
		
		ExecutorService executorService = Executors.newFixedThreadPool(5);

		for (File fileName : files) {
			executorService.execute(new FileLoader(fileName));
		}
		System.out.println("Completed scheduling the jobs..");
		
	}
	

}
