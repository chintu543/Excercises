package Oops;

import java.util.Arrays;

public class Student extends Person {
	
	int i=0;
	private int numCourses;
	private String courses[];
	private int grades[];
	
	Student(){
		super();
	}
	
	Student(String name, String address){
		super(name, address);
	}
	
	public void courseNum(int i) {
		
		numCourses = i;
		courses = new String[i];
		grades = new int[i];
	}
	
	public void addCourseGrade(String Course, int grade) {
	
			this.courses[i]= Course;
			this.grades[i]= grade;
			i++;
	}
	
	@Override
	public String toString() {
		return "Student [numCourses=" + numCourses + ", courses=" + Arrays.toString(courses) + ", grades="
				+ Arrays.toString(grades) + "]";
	}

	public void printGrades() {
       
		for(int i=0; i<numCourses; i++) {
			System.out.println("grade for " +courses[i] + " is " +grades[i]);
		}	
	}
	
	public double getAverageGrade() {
		
		 int total=0;
			for(int i=0; i<numCourses; i++) {
				total = total + grades[i];
			}
		 double AverageGrade = total/numCourses;
		 //System.out.println("Average grade of employee is " +AverageGrade);
		 return AverageGrade;
	}


}
