package Oops;

import java.util.Scanner;

public class UniversityApp {

	public static void main(String[] args) {
		
		Person p = new Person("Jimmy", "abc colony");
		System.out.println(p.getName());
		System.out.println(p.getAddress());
		p.toString();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter option 1 for student"+ "\n" +" 2 for Teacher");
		int option = sc.nextInt();
		
		 switch(option) {
		 case 1: Student s1 = new Student("Rajat","University Drive");
		         s1.courseNum(4);
		         System.out.println("Grades of " +s1.getName()+ " are:");
			     s1.addCourseGrade("Maths", 85);
			     s1.addCourseGrade("Physics", 87);
			     s1.addCourseGrade("Chemistry", 86);
			     s1.addCourseGrade("Biology", 90);
			     s1.printGrades();
			     System.out.println("Average Grade of "+s1.getName()+ " for his courses is: " +s1.getAverageGrade());
			     System.out.println(s1.toString());
			     System.out.println(s1.getAddress());
			 break;
			 
			 
		 case 2: Teacher t1 = new Teacher("Aakash", "Kinewest park");
		 		 t1.numCourses(3);
		 		 System.out.println("Teacher name is " +t1.getName());
		 		 System.out.println(t1.getAddress());
		 		 System.out.println(t1.addCourse("Mysql"));
		 		 System.out.println(t1.addCourse("C"));
		 		 System.out.println(t1.addCourse("phyton"));
		 		 System.out.println(t1.addCourse(null));
		 		 System.out.println(t1.toString());
		 		 
		 		 System.out.println("Courses taught before removing course");
		 		 t1.display();
		 		 
		 		 t1.removeCourse("Mysql");
		 		 System.out.println("Courses taught after deleting course");
		 		 t1.display();
		 		 
		 		 t1.removeCourse("phyton");
		 		 System.out.println("Courses taught after deleting course");
		 		 t1.display();
		 		 
		 	break;
		 		 default:
		 	break;
		
		 	
		}
		
		 sc.close();
	}

}
