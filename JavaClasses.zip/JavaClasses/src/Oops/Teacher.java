package Oops;

import java.util.Arrays;

public class Teacher extends Person {
	
	int o=0;
	int d,n,k,j;
	private int numCourses;
	private String[] courses;
	
	Teacher(){
		super();
	}
	
	public void numCourses(int i) {
		numCourses = i;
		courses = new String[i];
		
	}
	
	Teacher(String name, String address){
		super(name, address);
	}

	@Override
	public String toString() {
		return "Teacher [numCourses=" + numCourses + ", courses=" + Arrays.toString(courses) + "]";
	}
	
	public boolean addCourse(String course) {
		if(course!=null)  {
		this.courses[o] = course;
	      o++;
	      //System.out.println("Added Course successfully");
	    return true;
	}
		return false;
	}
	
	public void display() {
		for(int i=0; i<numCourses; i++) 
			System.out.println("Course taught by the teacher is: " +courses[i]);
	}
	
	public boolean removeCourse(String course) {
		
		for(int i=0; i<courses.length; i++) {
		 if(courses[i] == course) {
			 d=i;
		 }
		}
			 k= d+1;
			 n= numCourses;
			 j=k;
		     while(j<n) {
			 courses[j-1]=courses[j];
			 j = j+1;
		 }
		 n=n-1;
		 numCourses = n;
		return true;
	}
}
