package countFromFile;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.util.Scanner;
import java.util.regex.Pattern;

public class FileTotalCount {

	public static void main(String[] args) throws Exception {

		File file = new File("C:\\Users\\Sandeep Manchala\\Desktop\\Employee.csv");

		do {

			System.out.println("\n" + "Select an operation to perform:");
			System.out.println("1. Count the Words");
			System.out.println("2. Count the lines");
			System.out.println("3. Count the Numbers");
			System.out.println("4. Exit");
			System.out.println(" ");

			Scanner sc = new Scanner(System.in);
			int a = sc.nextInt();

			switch (a) {

			case 1:
				int c = countWords(file);
				System.out.println("Number of words in the file are " + c);
				break;
			case 2:
				int d = countLines(file);
				System.out.println("Number of lines in the file are " + d);
				break;
			case 3:
				int e = countNumbers(file);
				System.out.println("Number of Numbers in the file are " + e);
				break;
			case 4:
				System.exit(0);
			}
			sc.close();
		} while (true);

	}

	public static int countWords(File file) throws Exception {
		File infile = file;
		FileReader fr = new FileReader(infile);
		BufferedReader br = new BufferedReader(fr);
		String line = br.readLine();
		int count = 0;
		while (line != null) {
			String[] parts = line.split(",");
			for (String w : parts) {
				count++;
			}
			line = br.readLine();
		}
		br.close();
		return count;
	}

	public static int countLines(File file) throws Exception {
		File infile = file;
		FileReader fr = new FileReader(infile);
		BufferedReader br = new BufferedReader(fr);
		String line = br.readLine();
		int count = 0;
		while (line != null) {
			String[] lines = line.split(" ");
			for (String l : lines) {
				count++;
			}
			line = br.readLine();
		}
		br.close();
		return count;
	}

	public static int countNumbers(File file) throws Exception {
		File infile = file;
		FileReader fr = new FileReader(infile);
		BufferedReader br = new BufferedReader(fr);
		String line = br.readLine();
		int count = 0;
		while (line != null) {
			String[] numbers = line.split("\\d");
			for (String n : numbers) {
				count++;
			}
			line = br.readLine();
		}
		br.close();
		return count;
	}

}
